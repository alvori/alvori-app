<template>
    <h1 style="font-weight: 400; font-size: 4rem; line-height: 1;">404</h1>
    <p>Ooops... Page not found</p>
</template>

<script>
export default {
    name: '404',
}
</script>