<template>
  <div class="home">
      <a href="https://github.com/AlexxxRock/alvori-app" target="_blank">GitHub repository</a>
  </div>
</template>

<script>

export default {
  name: 'Home',
}
</script>