<template>
    <p>Starter tool kit SSR/PWA for Vue.js v3</p>
    <p>Enjoy development</p>
</template>

<script>
export default {
    name: 'About'
}
</script>